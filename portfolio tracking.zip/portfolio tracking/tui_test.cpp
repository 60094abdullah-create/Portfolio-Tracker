
#include <ftxui/component/component.hpp>
#include <ftxui/component/screen_interactive.hpp>
#include <ftxui/dom/elements.hpp>
#include <ftxui/screen/screen.hpp>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "Asset.h"
#include "Stock.h"
#include "Crypto.h"
#include "APIClient.h"

using namespace ftxui;
using namespace std;

static double parseDoubleOrZero(const string& text) {
    try {
        return stod(text);
    } catch (...) {
        return 0.0;
    }
}

static int runAutomatedAssetFormTest() {
    bool success = true;

    {
        vector<unique_ptr<Asset>> assets;
        string symbolInput = "AAPL";
        string quantityInput = "10";
        string stockDividendInput = "1.5";
        int assetTypeIndex = 0;

        double quantity = parseDoubleOrZero(quantityInput);
        double extraValue = parseDoubleOrZero(stockDividendInput);

        if (!symbolInput.empty() && quantity > 0.0) {
            if (assetTypeIndex == 0) {
                assets.push_back(make_unique<Stock>(symbolInput, quantity, extraValue));
            }
        }

        success &= assets.size() == 1;
        success &= assets[0] && dynamic_cast<Stock*>(assets[0].get()) != nullptr;
    }

    {
        vector<unique_ptr<Asset>> assets;
        string symbolInput = "BTC";
        string quantityInput = "2";
        string cryptoStakingInput = "0.04";
        int assetTypeIndex = 1;

        double quantity = parseDoubleOrZero(quantityInput);
        double extraValue = parseDoubleOrZero(cryptoStakingInput);

        if (!symbolInput.empty() && quantity > 0.0) {
            if (assetTypeIndex != 0) {
                assets.push_back(make_unique<Crypto>(symbolInput, quantity, extraValue));
            }
        }

        success &= assets.size() == 1;
        success &= assets[0] && dynamic_cast<Crypto*>(assets[0].get()) != nullptr;
    }

    cout << (success ? "Asset form logic test PASSED\n" : "Asset form logic test FAILED\n");
    return success ? 0 : 1;
}

int main(int argc, char* argv[]) {
    vector<unique_ptr<Asset>> assets;
    map<string, double> prices;
    double totalNetWorth = 0.0;
    string lastRefresh = "Never";

    string symbolInput = "";
    string quantityInput = "0";
    string stockDividendInput = "0";
    string cryptoStakingInput = "0";
    int assetTypeIndex = 0;
    
    vector<string> assetTypes = {"Stock", "Crypto"}; 
    
    string statusMessage = "";
    Color statusColor = Color::GrayLight;

    auto formatMoney = [&](double value) {
        ostringstream oss;
        oss << fixed << setprecision(2) << value;
        return oss.str();
    };

    auto refreshPrices = [&]() {
        totalNetWorth = 0.0;
        prices.clear();
        for (const auto& asset : assets) {
            string symbol = asset->getSymbol();
            double price = APIClient::fetchLivePrice(symbol);
            prices[symbol] = price;
            totalNetWorth += asset->calculateValue(price);
        }

        auto now = chrono::system_clock::now();
        auto time = chrono::system_clock::to_time_t(now);
        ostringstream oss;
        oss << put_time(localtime(&time), "%Y-%m-%d %H:%M:%S");
        lastRefresh = oss.str();
    };

    if (argc > 1 && string(argv[1]) == "test") {
        return runAutomatedAssetFormTest();
    }

    auto screen = ScreenInteractive::TerminalOutput();

    auto promptInitialHoldings = [&]() {
        cout << "Enter number of initial holdings to add (0 to skip): ";
        int startupCount = 0;
        if (!(cin >> startupCount) || startupCount < 0) {
            cin.clear();
            startupCount = 0;
        }
        string line;
        getline(cin, line); 

        for (int i = 0; i < startupCount; ++i) {
            string symbol;
            cout << "Holding " << (i + 1) << " symbol: ";
            getline(cin, symbol);
            if (symbol.empty()) {
                --i;
                continue;
            }

            cout << "Quantity: ";
            getline(cin, line);
            double quantity = parseDoubleOrZero(line);

            cout << "Type [S]tock/[C]rypto: ";
            getline(cin, line);
            bool isCrypto = !line.empty() && (line[0] == 'C' || line[0] == 'c');

            cout << (isCrypto ? "Staking reward: " : "Dividend yield: ");
            getline(cin, line);
            double extraValue = parseDoubleOrZero(line);

            if (isCrypto) {
                assets.push_back(make_unique<Crypto>(symbol, quantity, extraValue));
            } else {
                assets.push_back(make_unique<Stock>(symbol, quantity, extraValue));
            }
        }

        if (!assets.empty()) {
            refreshPrices();
        }
    };

    promptInitialHoldings();

    Component symbol_input = Input(&symbolInput, "symbol");
    Component quantity_input = Input(&quantityInput, "quantity");
    Component stock_dividend_input = Input(&stockDividendInput, "dividend yield");
    Component crypto_staking_input = Input(&cryptoStakingInput, "staking reward");

    Component tab_bar = Toggle(&assetTypes, &assetTypeIndex);

    auto add_button = Button("Add asset", [&] {
        string symbol = symbolInput;
        double quantity = parseDoubleOrZero(quantityInput);
        double extraValue = assetTypeIndex == 0
            ? parseDoubleOrZero(stockDividendInput)
            : parseDoubleOrZero(cryptoStakingInput);

        if (symbol.empty()) {
            statusMessage = "Please enter a symbol.";
            statusColor = Color::Red;
            return;
        }
        if (quantity <= 0.0) {
            statusMessage = "Quantity must be greater than zero.";
            statusColor = Color::Red;
            return;
        }

        if (assetTypeIndex == 0) {
            assets.push_back(make_unique<Stock>(symbol, quantity, extraValue));
        } else {
            assets.push_back(make_unique<Crypto>(symbol, quantity, extraValue));
        }

        symbolInput.clear();
        quantityInput = "0";
        stockDividendInput = "0";
        cryptoStakingInput = "0";
        refreshPrices();
        statusMessage = "Added " + symbol + " successfully.";
        statusColor = Color::Green;
    });

    auto remove_button = Button("Remove last asset", [&] {
        if (!assets.empty()) {
            assets.pop_back();
            refreshPrices();
            statusMessage = "Removed last asset.";
            statusColor = Color::Yellow;
        }
    });

    auto refresh_button = Button("Refresh prices", [&] {
        refreshPrices();
        statusMessage = "Prices refreshed.";
        statusColor = Color::GrayLight;
    });

    auto exit_button = Button("Exit", screen.ExitLoopClosure());

    int form_selector = 0;
    int controls_selector = 0;
    int root_selector = 0;

    Components form_children = {
        tab_bar,
        symbol_input,
        quantity_input,
        stock_dividend_input | Maybe([&] { return assetTypeIndex == 0; }),
        crypto_staking_input | Maybe([&] { return assetTypeIndex == 1; }),
        add_button,
    };
    Component form = Container::Vertical(form_children, &form_selector);
    Components control_children = {remove_button, refresh_button, exit_button};
    Component controls = Container::Horizontal(control_children, &controls_selector);
    Components root_children = {form, controls};
    Component root = Container::Vertical(root_children, &root_selector);

    auto renderer = Renderer(root, [&] {
        Elements header;
        header.push_back(text(" Live Portfolio Dashboard ") | bold | center);
        header.push_back(text("Enter an asset symbol, quantity, and type.") | dim | center);
        header.push_back(text("Selected asset type: " + assetTypes[assetTypeIndex]) | color(Color::GrayLight));
        header.push_back(text("Assets tracked: " + to_string(assets.size())) | color(Color::GrayLight));
        header.push_back(separator());
        header.push_back(text("Last refresh: " + lastRefresh) | color(Color::GrayLight));
        header.push_back(text("Total net worth: $" + formatMoney(totalNetWorth)) | color(Color::Yellow) | bold);
        header.push_back(separator());

        Elements rows;
        rows.push_back(
            hbox(Elements{
                text("Symbol") | bold | color(Color::CyanLight),
                filler(),
                text("Price") | bold | color(Color::CyanLight),
                text("  "),
                text("Value") | bold | color(Color::CyanLight),
            }) | bold | border
        );

        if (assets.empty()) {
            rows.push_back(
                text("No assets added yet. Use the form below and click Add asset.") | center | color(Color::GrayLight) | border
            );
        }

        for (const auto& asset : assets) {
            string symbol = asset->getSymbol();
            double price = prices.count(symbol) ? prices[symbol] : 0.0;
            double value = asset->calculateValue(price);
            bool isStock = dynamic_cast<Stock*>(asset.get()) != nullptr;
            string type = isStock ? "STK" : "CRYPTO";
            string priceText = price > 0.0 ? "$" + formatMoney(price) : "N/A";
            string valueText = price > 0.0 ? "$" + formatMoney(value) : "N/A";
            Color valueColor = price > 0.0 ? Color::Green : Color::Red;

            rows.push_back(
                hbox(Elements{
                    text(symbol + " (" + type + ")") | color(Color::White),
                    filler(),
                    text(priceText) | color(valueColor),
                    text("  "),
                    text(valueText) | color(valueColor),
                }) | border
            );
        }

        Elements body;
        body.push_back(vbox(header));
        body.push_back(vbox(rows) | size(WIDTH, GREATER_THAN, 60));
        body.push_back(separator());
        body.push_back(form->Render() | border);
        body.push_back(text(statusMessage) | color(statusColor));
        body.push_back(separator());
        body.push_back(controls->Render() | center);

        return window(text("Portfolio Tracker"), vbox(body) | color(Color::Blue));
    });

    screen.Loop(renderer);
    return 0;
}