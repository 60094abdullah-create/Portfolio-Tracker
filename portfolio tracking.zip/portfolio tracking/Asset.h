#ifndef ASSET_H
#define ASSET_H

#include <string>

class Asset {
protected:
    std::string symbol;
    double quantity;

public:
    Asset(std::string sym, double qty); 
    virtual ~Asset() {}                 
    
    virtual double calculateValue(double currentMarketPrice) const = 0; 
    
    std::string getSymbol() const;     
};

#endif