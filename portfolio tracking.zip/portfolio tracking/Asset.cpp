#include "Asset.h"

Asset::Asset(std::string sym, double qty) : symbol(sym), quantity(qty) {}

std::string Asset::getSymbol() const {
    return symbol;
}