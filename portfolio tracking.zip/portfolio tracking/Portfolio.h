#ifndef PORTFOLIO_H
#define PORTFOLIO_H

#include <vector>
#include "Asset.h"
class Portfolio {
private:
    std::vector<Asset*> investments; 

public:
    ~Portfolio(); 
    void addAsset(Asset* newAsset);
    double calculateTotalNetWorth() const;
};

#endif