#include "APIClient.h" 
#include "Portfolio.h"
#include <iostream>

using namespace std;

Portfolio::~Portfolio() {
    for (Asset* asset : investments) {
        delete asset; 
    }
    investments.clear();
}

void Portfolio::addAsset(Asset* newAsset) {
    investments.push_back(newAsset);
}

double Portfolio::calculateTotalNetWorth() const {
    double totalNetWorth = 0.0;

    for (Asset* asset : investments) {
        string symbol = asset->getSymbol();
        
        double livePrice = APIClient::fetchLivePrice(symbol); 
        totalNetWorth += asset->calculateValue(livePrice); 
    }
    
    return totalNetWorth;
}