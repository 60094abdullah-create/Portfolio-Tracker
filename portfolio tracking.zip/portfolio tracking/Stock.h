#ifndef STOCK_H
#define STOCK_H

#include "Asset.h"

class Stock : public Asset {
private:
    double dividendYield; 

public:
    Stock(std::string sym, double qty, double divYield);
    
    double calculateValue(double currentMarketPrice) const override; 
};

#endif