#include "APIClient.h"
#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>
#include <curl/curl.h>

using namespace std;

size_t WriteCallback(void* contents, size_t size, size_t nmemb, string* userp) {
    userp->append(static_cast<char*>(contents), size * nmemb);
    return size * nmemb;
}

static string normalizeSymbol(const string& symbol) {
    string result = symbol;
    transform(result.begin(), result.end(), result.begin(), [](unsigned char c){ return static_cast<char>(toupper(c)); });
    return result;
}

static string normalizeStockSymbol(const string& symbol) {
    static const unordered_map<string, string> stockLookup = {
        {"AAPL.US", "AAPL.US"},
        {"AAPL.O", "AAPL.US"},
        {"NASDAQ:AAPL", "AAPL.US"},
        {"NYSE:AAPL", "AAPL.US"},
        {"IBM.N", "IBM.US"},
        {"NYSE:IBM", "IBM.US"},
        {"LON:BP", "BP.L"},
        {"LSE:BP", "BP.L"},
        {"BP.L", "BP.L"},
        {"VOD.L", "VOD.L"},
        {"LSE:VOD", "VOD.L"},
        {"LON:VOD", "VOD.L"},
        {"TOR:RY", "RY.TO"},
        {"TSX:RY", "RY.TO"},
        {"TSE:RY", "RY.TO"},
        {"RY.TO", "RY.TO"},
        {"BMW.DE", "BMW.DE"},
        {"DAI.DE", "DAI.DE"},
        {"SHEL.L", "SHEL.L"},
        {"NESN.SW", "NESN.SW"},
        {"FWB:BMW", "BMW.F"},
        {"FWB:SAP", "SAP.F"},
        {"FRA:BMW", "BMW.F"},
        {"FRA:SAP", "SAP.F"},
        {"HK:0700", "0700.HK"},
        {"HK:0005", "0005.HK"},
        {"PA:BNP", "BNP.PA"},
        {"PA:ORA", "ORA.PA"},
        {"AS:ASML", "ASML.AS"},
        {"AS:PHIA", "PHIA.AS"}
    };

    auto it = stockLookup.find(symbol);
    if (it != stockLookup.end()) {
        return it->second;
    }

    size_t colonPos = symbol.find(':');
    if (colonPos != string::npos) {
        string market = symbol.substr(0, colonPos);
        string base = symbol.substr(colonPos + 1);
        if (market == "NASDAQ" || market == "NYSE" || market == "AMEX" || market == "NSE") {
            return base + ".US";
        }
        if (market == "LON" || market == "LSE") {
            return base + ".L";
        }
        if (market == "TSX" || market == "TOR" || market == "TSE") {
            return base + ".TO";
        }
        if (market == "DE") {
            return base + ".DE";
        }
        if (market == "FWB" || market == "FRA") {
            return base + ".F";
        }
        if (market == "SWX") {
            return base + ".SW";
        }
        if (market == "HK") {
            return base + ".HK";
        }
        if (market == "PA") {
            return base + ".PA";
        }
        if (market == "AS") {
            return base + ".AS";
        }
    }

    size_t dotPos = symbol.rfind('.');
    if (dotPos != string::npos) {
        return symbol;
    }

    return symbol + ".US";
}

static bool isCryptoSymbol(const string& symbol) {
    static const unordered_map<string, string> coinIdMap = {
        {"BTC", "bitcoin"},
        {"ETH", "ethereum"},
        {"LTC", "litecoin"},
        {"XRP", "ripple"},
        {"DOGE", "dogecoin"},
        {"ADA", "cardano"},
        {"DOT", "polkadot"},
        {"SOL", "solana"}
    };
    return coinIdMap.find(symbol) != coinIdMap.end();
}

static string symbolToCoinGeckoId(const string& symbol) {
    static const unordered_map<string, string> coinIdMap = {
        {"BTC", "bitcoin"},
        {"ETH", "ethereum"},
        {"LTC", "litecoin"},
        {"XRP", "ripple"},
        {"DOGE", "dogecoin"},
        {"ADA", "cardano"},
        {"DOT", "polkadot"},
        {"SOL", "solana"}
    };

    auto it = coinIdMap.find(symbol);
    if (it != coinIdMap.end()) {
        return it->second;
    }

    string lowerSymbol = symbol;
    transform(lowerSymbol.begin(), lowerSymbol.end(), lowerSymbol.begin(), [](unsigned char c){ return static_cast<char>(tolower(c)); });
    return lowerSymbol;
}

static bool parseUsdPrice(const string& json, const string& coinId, double& outPrice) {
    string coinToken = '"' + coinId + '"';
    size_t coinPos = json.find(coinToken);
    if (coinPos == string::npos) {
        return false;
    }

    size_t usdPos = json.find("\"usd\"", coinPos);
    if (usdPos == string::npos) {
        return false;
    }

    size_t colonPos = json.find(':', usdPos);
    if (colonPos == string::npos) {
        return false;
    }

    size_t valueStart = json.find_first_not_of(" \t\n\r", colonPos + 1);
    if (valueStart == string::npos) {
        return false;
    }

    size_t valueEnd = valueStart;
    if (json[valueStart] == '"') {
        valueStart++;
        valueEnd = json.find('"', valueStart);
        if (valueEnd == string::npos) {
            return false;
        }
    } else {
        while (valueEnd < json.size()) {
            unsigned char c = static_cast<unsigned char>(json[valueEnd]);
            if (!(isdigit(c) || c == '.' || c == '-' || c == '+' || c == 'e' || c == 'E')) {
                break;
            }
            valueEnd++;
        }
    }

    if (valueEnd <= valueStart) {
        return false;
    }

    string priceStr = json.substr(valueStart, valueEnd - valueStart);
    try {
        outPrice = stod(priceStr);
        return true;
    } catch (const exception&) {
        return false;
    }
}

static bool parseStooqCsvPrice(const string& csv, double& outPrice) {
    size_t linePos = csv.find('\n');
    if (linePos == string::npos) {
        return false;
    }

    string secondLine = csv.substr(linePos + 1);
    size_t endLine = secondLine.find_first_of("\r\n");
    if (endLine != string::npos) {
        secondLine = secondLine.substr(0, endLine);
    }

    vector<string> fields;
    size_t start = 0;
    while (start < secondLine.size()) {
        size_t commaPos = secondLine.find(',', start);
        if (commaPos == string::npos) {
            fields.push_back(secondLine.substr(start));
            break;
        }
        fields.push_back(secondLine.substr(start, commaPos - start));
        start = commaPos + 1;
    }

    // Stooq CSV fields: Symbol,Date,Time,Open,High,Low,Close,Volume
    if (fields.size() < 7) {
        return false;
    }

    const string& closeField = fields[6];
    if (closeField.empty() || closeField == "N/D") {
        return false;
    }

    try {
        outPrice = stod(closeField);
        return true;
    } catch (const exception&) {
        return false;
    }
}

static double getStaticAssetPrice(const string& symbol) {
    static const unordered_map<string, double> fallbackPrices = {
        {"AAPL", 170.0},
        {"MSFT", 320.0},
        {"GOOGL", 140.0}
    };

    auto it = fallbackPrices.find(symbol);
    return (it != fallbackPrices.end()) ? it->second : 0.0;
}

static bool fetchFromUrl(const string& url, string& output) {
    CURL* curl = curl_easy_init();
    if (!curl) {
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &output);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "PortfolioTracker/1.0");

    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    return res == CURLE_OK;
}

double APIClient::fetchLivePrice(const string& symbol) {
    string normalizedSymbol = normalizeSymbol(symbol);
    bool isCrypto = isCryptoSymbol(normalizedSymbol);
    string requestUrl;

    if (isCrypto) {
        string coinId = symbolToCoinGeckoId(normalizedSymbol);
        requestUrl = "https://api.coingecko.com/api/v3/simple/price?ids=" + coinId + "&vs_currencies=usd";
    } else {
        string stooqSymbol = normalizeStockSymbol(normalizedSymbol);
        requestUrl = "https://stooq.com/q/l/?s=" + stooqSymbol + "&f=sd2t2ohlcv&h&e=csv";
    }

    string response;
    if (!fetchFromUrl(requestUrl, response)) {
        cerr << "Network request failed for symbol " << symbol << "." << endl;
        double fallbackPrice = getStaticAssetPrice(normalizedSymbol);
        if (fallbackPrice > 0.0) {
            cerr << "Using fallback price for symbol " << symbol << ": " << fallbackPrice << endl;
        }
        return fallbackPrice;
    }

    double price = 0.0;
    if (isCrypto) {
        string coinId = symbolToCoinGeckoId(normalizedSymbol);
        if (parseUsdPrice(response, coinId, price)) {
            return price;
        }
    } else {
        if (parseStooqCsvPrice(response, price)) {
            return price;
        }
    }

    price = getStaticAssetPrice(normalizedSymbol);
    if (price > 0.0) {
        cerr << "Using fallback price for symbol " << symbol << ": " << price << endl;
    } else {
        cerr << "Unable to resolve live price for symbol " << symbol << "." << endl;
    }

    return price;
}