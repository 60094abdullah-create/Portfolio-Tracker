#ifndef CRYPTO_H
#define CRYPTO_H

#include "Asset.h"

class Crypto : public Asset {
private:
    double stakingRewards; 

public:
    Crypto(const std::string& sym, double qty, double stakingRewards);
    
    double calculateValue(double currentMarketPrice) const override; 
};

#endif