#include <iostream>
#include "Portfolio.h"
#include "Stock.h"
#include "Crypto.h"

using namespace std;

int main() {
    cout << "Live Portfolio Tracker " << endl;

    Portfolio myPortfolio;

    myPortfolio.addAsset(new Stock("AAPL", 10.0, 15.0)); 
    myPortfolio.addAsset(new Crypto("BTC", 0.5, 0.0));   

    cout << "\nFetching live market data..." << endl;
    double totalValue = myPortfolio.calculateTotalNetWorth();

    cout << "\nTotal Portfolio Value: $" << totalValue << endl;

    return 0;
}