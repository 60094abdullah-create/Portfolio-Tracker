
#ifndef APICLIENT_H
#define APICLIENT_H

#include <string>

class APIClient {
public:
    static double fetchLivePrice(const std::string& symbol); 
};

#endif