#include "Stock.h"

Stock::Stock(std::string sym, double qty, double divYield) 
    : Asset(sym, qty), dividendYield(divYield) {}

double Stock::calculateValue(double currentMarketPrice) const {
    return (quantity * currentMarketPrice) + dividendYield; 
}