#include <cassert>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "Asset.h"
#include "Stock.h"
#include "Crypto.h"

static double parseDoubleOrZero(const std::string& text) {
    try {
        return std::stod(text);
    } catch (...) {
        return 0.0;
    }
}

int main() {
    bool success = true;

    {
        std::vector<std::unique_ptr<Asset>> assets;
        std::string symbolInput = "AAPL";
        std::string quantityInput = "10";
        std::string stockDividendInput = "1.5";
        int assetTypeIndex = 0;

        double quantity = parseDoubleOrZero(quantityInput);
        double extraValue = parseDoubleOrZero(stockDividendInput);

        if (!symbolInput.empty() && quantity > 0.0) {
            if (assetTypeIndex == 0) {
                assets.push_back(std::make_unique<Stock>(symbolInput, quantity, extraValue));
            } else {
                assets.push_back(std::make_unique<Crypto>(symbolInput, quantity, extraValue));
            }
        }

        success &= assets.size() == 1;
        success &= assets[0]->getSymbol() == "AAPL";
        success &= dynamic_cast<Stock*>(assets[0].get()) != nullptr;
    }

    {
        std::vector<std::unique_ptr<Asset>> assets;
        std::string symbolInput = "BTC";
        std::string quantityInput = "2";
        std::string cryptoStakingInput = "0.04";
        int assetTypeIndex = 1;

        double quantity = parseDoubleOrZero(quantityInput);
        double extraValue = parseDoubleOrZero(cryptoStakingInput);

        if (!symbolInput.empty() && quantity > 0.0) {
            if (assetTypeIndex == 0) {
                assets.push_back(std::make_unique<Stock>(symbolInput, quantity, extraValue));
            } else {
                assets.push_back(std::make_unique<Crypto>(symbolInput, quantity, extraValue));
            }
        }

        success &= assets.size() == 1;
        success &= assets[0]->getSymbol() == "BTC";
        success &= dynamic_cast<Crypto*>(assets[0].get()) != nullptr;
    }

    std::cout << (success ? "Asset form test: PASS\n" : "Asset form test: FAIL\n");
    return success ? 0 : 1;
}
