#include "Crypto.h"

Crypto::Crypto(const std::string& sym, double qty, double stakingRewards)
    : Asset(sym, qty), stakingRewards(stakingRewards) {}

double Crypto::calculateValue(double currentMarketPrice) const {
    return (quantity * currentMarketPrice) + stakingRewards;
}