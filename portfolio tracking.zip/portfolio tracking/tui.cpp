#include <ftxui/component/component.hpp>
#include <ftxui/component/screen_interactive.hpp>
#include <ftxui/dom/elements.hpp>
#include <ftxui/screen/screen.hpp>
#include <chrono>
#include <iomanip>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "Asset.h"
#include "Stock.h"
#include "Crypto.h"
#include "APIClient.h"

using namespace ftxui;
using namespace std;

int main() {
    vector<unique_ptr<Asset>> assets;
    assets.push_back(make_unique<Stock>("AAPL", 10.0, 15.0));
    assets.push_back(make_unique<Stock>("VOD.L", 40.0, 0.0));
    assets.push_back(make_unique<Crypto>("BTC", 0.12, 0.0));
    assets.push_back(make_unique<Crypto>("ETH", 1.3, 0.0));

    map<string, double> prices;
    double totalNetWorth = 0.0;
    string lastRefresh = "Never";

    auto formatMoney = [&](double value) {
        ostringstream oss;
        oss << fixed << setprecision(2) << value;
        return oss.str();
    };

    auto refreshPrices = [&]() {
        totalNetWorth = 0.0;
        for (const auto& asset : assets) {
            string symbol = asset->getSymbol();
            double price = APIClient::fetchLivePrice(symbol);
            prices[symbol] = price;
            totalNetWorth += asset->calculateValue(price);
        }

        auto now = chrono::system_clock::now();
        auto time = chrono::system_clock::to_time_t(now);
        ostringstream oss;
        oss << put_time(localtime(&time), "%Y-%m-%d %H:%M:%S");
        lastRefresh = oss.str();
    };

    refreshPrices();

    auto screen = ScreenInteractive::TerminalOutput();

    auto refresh_button = Button("Refresh prices", [&](){
        refreshPrices();
    });
    auto exit_button = Button("Exit", screen.ExitLoopClosure());
    auto controls = Container::Horizontal({refresh_button, exit_button});

    auto renderer = Renderer(controls, [&]() {
        Elements header = {
            text(" Live Portfolio Dashboard ") | bold | center,
            text("Powered by FTXUI") | dimmed | center,
            separator(),
            text("Last refresh: " + lastRefresh) | color(Color::LightGray),
            text("Total net worth: $" + formatMoney(totalNetWorth)) | color(Color::Yellow) | bold,
            separator(),
        };

        Elements rows;
        rows.push_back(
            hbox({
                text("Symbol") | bold | color(Color::LightCyan),
                filler(),
                text("Price") | bold | color(Color::LightCyan),
                text("  "),
                text("Position Value") | bold | color(Color::LightCyan)
            }) | bold | border
        );

        for (const auto& asset : assets) {
            string symbol = asset->getSymbol();
            double price = prices[symbol];
            double value = asset->calculateValue(price);
            string type = dynamic_cast<Stock*>(asset.get()) ? "STK" : "CRYPTO";
            string priceText = price > 0.0 ? "$" + formatMoney(price) : "N/A";
            string valueText = price > 0.0 ? "$" + formatMoney(value) : "N/A";
            Color color = price > 0.0 ? Color::Green : Color::Red;

            rows.push_back(
                hbox({
                    text(symbol + " (" + type + ")") | color(Color::White),
                    filler(),
                    text(priceText) | color(color),
                    text("  "),
                    text(valueText) | color(color)
                }) | border
            );
        }

        return window(
            text("Portfolio Tracker"),
            vbox({
                vbox(header),
                vbox(rows) | size(WIDTH, GREATER_THAN, 55),
                separator(),
                controls->Render() | center
            }) | padding(1, 1)
        ) | border | color(Color::Blue);
    });

    screen.Loop(renderer);
    return 0;
}
